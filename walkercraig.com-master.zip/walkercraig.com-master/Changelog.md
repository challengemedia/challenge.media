# Royce Jekyll Theme

## Version 1.2.0 – 05 March 2020:

- added: Royce version for GitHub pages

## Version 1.1.0 – 01 March 2020:

- added: Simple Jekyll search

Files updated:

- .gitignore
- Gemfile
- _config.yml
- assets/css/style.scss

Files added:

- search.html
- search.json
- _sass/_search.scss
- assets/js/simple-jekyll-search.min.js

Files deleted:

- Gemfile.lock

## Version 1.0.0
- initial release
