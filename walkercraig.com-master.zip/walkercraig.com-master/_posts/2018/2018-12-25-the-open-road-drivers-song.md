---
layout: post
tag: [ Poems ]
title: The Open Road/Driver's Song
---

<br/>

Over the river and through the wood

To anywhere we want to go

God knows the way to the happy someday

At the end of the open road

Over the river and through the wood

To anywhere we want to go

The road is the way that we like to play

In the rain and the shine and the snow

Over the river and through the wood

Oh hear the engine roar

Man and machine a powerful team

Together a sense they could soar

Over the river and through the wood

Our cares all fall behind

With smiles on our face as we all give chase

For freedom and peace of mind

Over the river and through the wood

To anywhere we want to go

The road is the way that we like to play

In the rain and the shine and the snow

Over the river and through the wood

To anywhere we want to go

God knows the way to the happy someday

At the end of the open road

<br/>
