---
layout: post
tag: [ Poems ]
title: The Unsung Hero
---

<br/>

An elder takes the final breath

A newborn takes the first

The village prays upon the news

And wonders which is worse

A lifetime come, a lifetime gone

And lifetimes yet to be

Which life will be the better life?

Life they will or will not see?

The old look back on seven ages

On life lived as they could

And pass as best to repress regret

And remorse for what they would

The record writ in Hæven's pages

Saved neatly in the vault

Judgment offered to all seeing eyes

To gaze upon their fault

The babe now face' the seven ages

An empty book to fill

But in the blank rests boundless hope

That this dust is made from Will

For any all can be a light

Any one a fallen star

And good or bad Will Just depend

From where you look, from where you are

For any all can be the one

Any one can be a zero

All are gifted this potential

So sing Unsung Hero

<br/>
