---
layout: post
tag: [ Poems ]
title: The Somewhere Bird
---

<br/>

Somewhere

Dawn breaks

Morning is come

Somewhere

A little bird ventures out on the branch and begins his hymn

Of praise

Of thanks

For the warmth that washes over

Witness to the Glory

He sings for thee

He sings for we

He sings for all His creatures that have made it through another night

Somewhere

Dawn breaks

Morning is come

<br/>
