---
layout: post
tag: [ Poems ]
title: For a Sign on a Roadside Tavern
---

<br/>

Wherein is contained

<br/>

Salutations, libations, bad judgements, and good conversations.

Come rain or come shine, a friend one may find,

With humble soul and with curious mind.

As long as one carry a smile to this place,

And set in their heart a place for the Grace,

One never knows what story awaits

Beyond the next moment in time and this space.

<br/>

Fitted to a latitude of forty-two degrees,

And a meridian of six hours west from London.

All Travelers welcome.

The well-behaved are the well-served.

<br/>
