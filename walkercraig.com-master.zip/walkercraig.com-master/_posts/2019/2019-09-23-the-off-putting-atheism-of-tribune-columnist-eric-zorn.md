---
layout: post
tag: [ Read ]
title: "The Off-Putting Atheism of Tribune Columnist Eric Zorn"
---

Craig responds to a bizarre column published by the Chicago Tribune, in which columnist Eric Zorn let the city know just how offended he was after last weeks game. Zorn was offended when Chicago Bears' rookie placekicker, Eddy Piñeiro, thanked his Lord and Savior, Jesus Christ, after making a game-winning field goal.

---

In a bizarre column published last Monday by the Chicago Tribune, 61 going on 16-year-old columnist, Eric Zorn, informed the city he was super offended at the audacity and general way in which new Chicago Bears kicker Eddy Piñeiro acknowledged his faith in his own personal lord and savior, commonly known to readers as, Jesus Christ, and that he really wants us to be more considerate to loser atheists.((Calm down, atheists. I'm talking about atheists on the losing team or in the losing fanbase, as Zorn implied. It sounded funny and I'm just having a bit of fun.)) I honestly believed((Aw shucks, there I go...I didn't even make it further than the second sentence. Sorry, Eric.)) that I had missed a joke and largely brushed it off until later, when I heard Zorn clarify his column while appearing on the Bill and Wendy Show on WGN Radio 720 AM, and reiterate later in the week while appearing on the John Williams Show. As it turns out, Eric Zorn, an adult, was actually offended by Eddy Piñeiro's postgame jubilation.

I mean, it's [current year], okay? Atheists have neural impulses that move an organism to action, prompting automatic reactive behavior that has been adapted through evolution as a survival mechanism to meet a survival need, too, you know?

<h3><a href="https://www.chicagojournal.com/the-off-putting-atheism-of-tribune-columnist-eric-zorn">Read the rest in the Chicago Journal...</a></h3>

<br/>
