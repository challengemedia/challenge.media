---
layout: post
tag: [ Poems ]
title: The Sun Rose Today
---

<br/>

The Sun rose today

With a light of intimate ideal

As a parent's kiss upon the brow

Its warmth a like appeal

A kiss to say I'm here now

And forever I'll be with you

Even when my kiss is nothing more

Than a memory you once knew

A shadow play upon the face of home

As the Spirit on the surface of the deep

A dance through tree and skip through field

Innocent

As a babe's soft laugh can make one weep

A wink

A glint in the corner of the eye

A nod from a knowing friend

I am He and He is Me

And We are Thee to the end

The Sun rose today

I am here

<br/>
