---
layout: post
tag: [ Read ]
title: "In Case You Missed It: WGN Chicago Mayoral Forum"
---

Craig was tasked with watching the 2019 Chicago Mayoral Candidates on the broadcast of the WGN Chicago Mayoral Forum at Steinmetz College Prep in the Belmont Cragin neighborhood on the city's Far Northwest Side. He attempted a live blog which he hopes to never do again.

---

In case you missed it, on Thursday night, almost all of the 2019 Chicago Mayoral Candidates showed up to Steinmetz College Prep in the Belmont Cragin neighborhood on the city's Far Northwest Side to participate in WGN's Chicago Mayoral Forum.

<h3><a href="https://www.chicagojournal.com/in-case-you-missed-it-wgn-chicago-mayoral-forum">Read the rest in the Chicago Journal...</a></h3>

<br/>
