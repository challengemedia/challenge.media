---
layout: post
tag: [ Poems ]
title: As All Must and the Lucky Do
---

<br/>

Along the banks of the Mississippi

Along the shore of the Great Lake

Along the innumerable sweetwater veins, inlets, tributaries, and puddles that lie undisturbed in quiet reflection of the big sky, rests

A boat

No bigger than a Dingy but as big as a Carrack

Depending on perspective

Depending on imagination

Warped and split and faded

Abandoned

Abandoned to old age

Not old age in the sense that the boat was old and needed to be replaced

Though that be true, too

Abandoned to old age because the caretakers of that humble craft grew up and moved on

As all must and the lucky do

A home for a Signature Spider

Or a nesting place for a Black Tern or a Wood Thrush

Quiet neighbors to that which is embedded deep in that discarded wood

That which has permeated into the stains and pounded into the dings and shaped into the carvings

That which is not easily described but has been left there, all the same

The tragedy and the comedy

The first confession to another person not named Mom and Dad

Declarations of beliefs that were shattered and changed and received once more

The first beers taken from an alcoholic stepfather's cooler underneath the workbench in the garage

The dedications to dreams and the toasts to failures

The tears that flowed brisk as the current down the cheek and off the tip of the chin to fall into the still damp slop under toe

The laughs as countless as the stars laughed underneath

The lonely private reflections upon their place and their existence in the universe as they floated in the darkness

The sum of All Existence

Buoyed by a little boat

As it moved upon the face of the waters

And it's there

Along the banks of the Mississippi

Along the shore of the Great Lake

Along the innumerable sweetwater veins, inlets, tributaries, and puddles that lie undisturbed in quiet reflection of the big sky, somewhere

They long to return again

To collect that which was abandoned

Lost, perhaps unknowing and by accident

For maybe

If they can collect the Gone

Save the Fallen

Find the Departed

Just maybe

If imagined hard enough

If wished hard enough

If prayed hard enough

Maybe

These ancient waters will see fit to bless them and lift the boat loose from its resting place and

In their present encampment

Further down the river or on the other shore

They'll look toward the bend or squint at the horizon where it will appear

And find them again

<br/>

Little pieces of Soul litter the land and muddy the waters

Perhaps unknowing and by accident

Given and received as gifts

Added to our collection

Traded

Like baseball cards

<br/>
