---
layout: post
tag: [ Poems ]
title: Sleep Now, Child
---

<br/>

Sleep now, Child

Adore the feeling

A long day gone

The Soul needs healing

Be still your heart

Calm the beating

Tomorrow comes

And all newcomers deserve a greeting

Lay rest your mind

And keep believing

The dreams you dream

We'll sing the achieving

Be not afraid

Of dark and shadow teasing

Be not afraid

Of unknown fearing

Find your path

Practice eternal seeking

And never forget

The dreams you're weaving

Are yours alone

And your mind receiving

Creation's gift

Of pioneering

Outcome testing

Void of pleading

The best path forward

In search of meaning

The only lesson

Worth the bleeding

We are forever hunting

For the clearing

Where the light reigns

And grants us our best seeing

Where Wisdom basks

And seeds our freeing

Remember the Way

For others, be the gleaming

<br/>

Sleep now, Child

Adore the feeling

A long day gone

The Soul needs healing

Receive the Grace

And let thy burden leaven

Embrace your gift

And glimpse of Hæven

<br/>
