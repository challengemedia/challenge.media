---
layout: post
tag: [ Poems ]
title: I Am Afraid
---

<br/>

I am afraid for the rest of my days

And afraid of the æfter, that causes all souls its malaise

I am afraid sitting here in our home, safe and warm

Free from the worries outside, getting caught in the storm

I am afraid as you rest your head in my lap on down pillow

With the fire aglow and the snow gently falling just beyond our window

I am afraid for the beat of your breath as it rises and falls and rises the chest

For I can but wish to hold your heart and help it forever beat best

I am afraid that I am already enchanted, and have no more Sin worth being recanted

That I have been gifted, the dream has been granted

As my love blooms here among the holly, the ivy, the edelweiss

I am afraid I have reached Paradise

For if there truly be something better than this

Something beyond the sweet goodnight kiss in this scenery's bliss

If there truly be 'yond the horizon Wonders more

Where all humble travelers born await the barrelman's cry for æon's undiscovered shore

I am not worthy

I am not fit

I am damned

My fate has been writ

I am afraid the magic Prophets promise I am not destined to see

But I am comforted, for here in your eyes shine the stars meant for me

<br/>
