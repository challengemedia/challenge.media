---
layout: post
tag: [ Read ]
title: "New in Town? The Names May Change but How Things Work Don’t, Bub."
---

Craig revisits a famous column that won Mike Royko a Pulitzer Prize in 1972, and Craig attempts to update it for our modern times. Sadly, Craig finds that the names may change but the story stays the same.

---

Jake Ecko has been in Chicago only a few months, so he wasn’t sure if the wildin’ out in the YouTube videos he watched or the stuff trending on social media he read on his cell phone were really true.

You can’t blame a newcomer for wondering. Rich high-rise owners pleading poverty for tax breaks; corporations relocating headquarters doing the same; shoeboxes and refrigerators filled with money; gangs of young people running through the streets with little or no repercussions due to potential election ramifications; violent offenders released on little or no bond due to the same; fictitious racists-sexists-bigots-homophobes and fictitious children in a politician’s Who’s Who entry.

<h3><a href="https://www.chicagojournal.com/new-in-town">Read the rest in the Chicago Journal...</a></h3>

<br/>
