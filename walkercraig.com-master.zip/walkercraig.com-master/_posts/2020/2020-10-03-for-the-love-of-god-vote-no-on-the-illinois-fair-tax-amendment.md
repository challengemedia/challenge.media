---
layout: post
tag: [ Read ]
title: For the Love of God, Vote NO on the Illinois "Fair" Tax Amendment
---

Craig observes how his Illinois state legislators are trying to trick you, dupe you, fool you, con you, deceive, delude, swindle, and fleece you, exploit you, squeeze you, sucker you, sap you, make you chump, patsy, goose, and fall guy after they bleed you dry.

---

It's formally titled the "Allow for Graduated Income Tax Amendment" but you wouldn't know that based on how they're attempting to sell it. It's being sold under a disguise of fairness and they've been successful in making everyone use the word fair to talk about it. 

<h3><a href="https://www.chicagojournal.com/for-the-love-of-god-vote-no-on-the-illinois-fair-tax/">Read the rest in the Chicago Journal...</a></h3>

<br/>
