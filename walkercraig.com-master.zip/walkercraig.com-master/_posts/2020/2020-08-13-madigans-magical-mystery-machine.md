---
layout: post
tag: [ Read ]
title: Madigan's Magical Mystery Machine
---

Craig takes a look at the history of Mike Madigan in the state of Illinois.

---

On January 13, 1971, a fresh-faced 28 year old lawyer named Mike Madigan assumed office as a member of the Illinois House of Representatives, serving the 22nd district of Chicago's 13th Ward. He's still there. 

<h3><a href="https://www.chicagojournal.com/madigans-magical-mystery-machine/">Read the rest in the Chicago Journal...</a></h3>

<br/>
