---
layout: post
tag: [ Poems ]
title: And Yet Here I Remain
---

<br/>

I can no longer pretend that I understand

The cruel, wicked turns this strange tale demands

What could be a simple story of a boy made man

Made proud by the boy he made from His word and from His Hand

It be found necessary to deceive and betray and belittle the secret he holds most grande

All to keep the mystery from that of his clan

It has become quite clear that no one here knows

That all this pusillanimous theatre

And glorified minstrel shows

And all the poetry and pretty profound prose

Is manufactured of pulchers to please children asking why the wind blows

That pretend deliverance is posture verbose

A lie that from cacophony can come one chosen compose

<br/>

And yet

Here I remain

<br/>

Amid sadness, amid strife

Loss in the lost, the twists of the knife

Would that strife perish among the gods and men!

Together forever in æven's Great Glen

Would I could I even remember then?

Life - O! Life!

Wandering, pondering, rudderless Life

A confrontation

A War upon War

It's the Price

Yet still common melancholy yields

Verse, Virtue, and Vice

<br/>

And yet

Here I remain

<br/>

The fruits of our labors and souls of our nurtures

Are we guided or sighted in the light of the searchers?

Will we now or never know the difference in pleasure

Between treasure and leisure and the All-Mighty measure

Will I

I 

Sans equal

Sans naught

I, the Son of all who've fought

I, the Sum of all they've wrought

I, the Father of all to come

I, the Author of all to some

<br/>

And yet

Here I remain

<br/>
