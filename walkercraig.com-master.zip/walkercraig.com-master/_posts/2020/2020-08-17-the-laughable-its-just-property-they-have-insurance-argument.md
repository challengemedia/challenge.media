---
layout: post
tag: [ Read ]
title: The Laughable "It's Just Property...They Have Insurance" Argument
---

For a moment, Craig asks you to ignore the going street value of smerch like Gucci handbags, old school Nike kicks, or the women's autumn cardigan collection at Macy's, and take a closer look at the "it's just property...they have insurance..." argument in response to rioting.

---

It's true that Ariel Atkins, one of the members of the Chicago chapter of the Black Lives Matter Organization, inspired this piece after she catapulted herself into a national story before the assembled media cameras last week. Here was their money shot:

<h3><a href="https://www.chicagojournal.com/the-laughable-its-just-property-they-have-insurance-argument/">Read the rest in the Chicago Journal...</a></h3>

<br/>
