---
layout: post
tag: [ Read ]
title: "A Brief History of Columbus in Chicago"
---

It occurred to Craig the other day that it might be confusing for new tourists or visiting vigilantes in our city as to why a Christopher Columbus statue would be here at all. The least he could do is provide context.

---

Lost in the cacophony of insults, social media hashtags, thrown rocks, police batons, sharpened PVC piping, frozen water bottles, tear gas, and fireworks, it appears the reasons and the motivations and the general history behind why a statue of Christopher Columbus stands in Chicago in the first place has either been mistakenly missed or intentionally ignored.

<h3><a href="https://www.chicagojournal.com/a-brief-history-of-columbus-in-chicago">Read the rest in the Chicago Journal...</a></h3>

<br/>
