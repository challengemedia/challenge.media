---
layout: post
tag: [ Poems ]
title: In a Public Garden, Late Summer
---

<br/>

Honeybees suckle on the tapped out tulips

Sunflower petals start to wane

Children rush beside and almost trip upon a stone

Mothers cry out fearful of the stain

Oleander spills barrels of apricots

Brimful are the wandering olfact wells

Ivy vines redecorate their weather worn homes

The spiders, ever quiet, weave their spells

The elms and the maples and the great red oaks

Know the change will be here sooner than they want

The pines share a laugh and they taunt it always is

And tease they're all a bunch of blissful debutantes

Late we stay, deep into the dusk

The crickets weep in tune within the willows

Swimming in fireflies that try to match the music of the stars

As the Maestro holds the rhythm of le Grande Composè

I confess

' d'n't know what an Artist was

Until I saw the Light

Reflecting off the moonshine shine

Shine down from its great height

Reflecting off the quiet lake

And off my eye and back

And off the face of those sweet waters

And into mine eye black

Upon all things on all the ærth

On all souls wrapped in their cocoon

Our dancing breath must reflect some unknown process of being

On the other side of Time's last swoon

From no where and from everywhere

I could almost feel my body begin to release all wrong

In the stillness of that long kiss good night

I began to hear the Song

<br/>
