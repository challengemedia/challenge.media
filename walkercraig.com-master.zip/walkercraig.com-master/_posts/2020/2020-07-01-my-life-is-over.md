---
layout: post
tag: [ Poems ]
title: My Life is Over
---

<br/>

My life is over

It is now yours

Heretofore now

Was but a sequence of wars

Defining, refining, enshrining

Mea Mores

Such simple Joy

I did not know there could be

That which once was

No more matters to me

Tomorrow and tomorrow and tomorrow

Is for thee

<br/>
