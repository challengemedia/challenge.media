---
layout: post
tag: [ Read ]
title: Lori Lightfoot is Losing the Plot
---

Craig takes some time out to discuss Lori Lightfoot's latest capitulation to the mob and encourages her to, rather than turn the car around, stop and ask for directions.

---

While Mayor Lori Lightfoot continues her over-the-top audition for no one to be the next face of the CNN docu-drama, Chicagoland, and appears to grow more frustrated by the day that Rahm's brother, Ari, or the Obama Family Netflix Production Company have yet to pick up the phone and get the triple threat the true audience she deserves, the city she was elected to lead is spiraling out of control faster than the Tik Tok buffering icon. It was spiraling long before Lori Lightfoot took office but, as that spiral spins faster and faster under her watch, her refusal to take any responsibility for her decision making in response to that spiral and the baffling contempt with which she treats seemingly everyone who dare question her authority, is going to earn her a new nickname. At the rate she's going, at best, Mayor Lightlost is going to lead this city into the middle of nowhere without a compass when it needs it most and, at worst, Mayor Leadfoot behind the wheel is going to lose control and drive this town into the metaphorical ditch.

<h3><a href="https://www.chicagojournal.com/lori-lightfoot-is-losing-the-plot">Read the rest in the Chicago Journal...</a></h3>

<br/>
