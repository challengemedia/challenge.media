---
layout: post
tag: [ Read ]
title: Brian Urlacher Posts on Social Media and the Wide World of Sports Pulls Out Their Hair
---

Not even Hall of Fame linebackers are given the benefit of the doubt for innocuous social media posts and Craig laughs at sports organizational nonsense. 

---

Judging by a quick review of the collective firestorm ignited by his social media activity last week, if it weren't Brian Urlacher's mug plastered up on every other billboard from Indiana to the Wisconsin border I suspect the influx of inquiries to Restore Hair would have crashed their system.

<h3><a href="https://www.chicagojournal.com/brian-urlacher-posts-on-social-media-and-the-wide-world-of-sports-pulls-out-their-hair/">Read the rest in the Chicago Journal...</a></h3>

<br/>
