---
layout: post
title: None Other
tag: [ Poems ]
---

<br/>

I' never met another one like me

Another one with my heart beat

Another one who' seen the things I' seen

Another one who dreams the dreams I' dream

Yet I know I'm go'n' find my way

If it takes me forever and a day

Wherever I may roam, wherever I may lay

I know it'll be in my own way

<br/>
