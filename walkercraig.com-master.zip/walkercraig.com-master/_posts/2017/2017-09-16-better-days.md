---
layout: post
tag: [ Poems ]
title: Better Days
---

<br/>

I remember

Better days

When I was young

And all I did was play

Now my mind

Is lost in the haze

And all my memories

Are starting to fade

It all just seems

Like such a waste

Like a young girl

Who lost the chaste

I don't mean

To overstate

It's just the hour

Is getting late

What have I become?

A cartoon

Of what I once was?

What have I become?

What have I become?

<br/>
