---
layout: post
tag: [ Poems ]
title: A Drunk Old Man at the Bar
---

<br/>

I...

Think I had too much to drink

O'cause I’m beginnen’ to think

A li'l too much about the passt

<br/> 

Like this glass here in fffront of me

I ne'er reali'e until it’s emptee

Tha' nothin’ good evah lastss

<br/>

Sooo

Fill up my glass again!

Have another drink with me my frien’

And let's raise a toas' to ourselves until the day begin aga'n

<br/>

We’re here, spinnin’ ‘round on this careousel

Just tryin’ tah liveit an' live it well

'til some day it stops and bids ye'adieu, bon voya', fare t'e' well

<br/>

Bartender!

Pour me sumthin’ straawng!

So I cen remember jus' whare itall went wrong

When I was a younga man

<br/>

An' please

Please play my favorite song

I promise it ayn’t toooo long

Tonigh' all that damn jukeboks has played are Saynt Valentyne shams

<br/>

My glass

Repreessents all æternity

Fillitup ag'in soon as it’s emptey

Just make sure you wash away all that memorey

<br/>

And on

And on andonand on it goes

And on and onandonandon it go'

And on andonandonandon it goes

And on andonandonandon

And on and on andonandon

Andon and on and on and on

And on

<br/>

Bartender!

You’s gah alla my money!

Please please pleeease have mersey on meee

An' fill my glass until my min' reaches the subli'e

<br/>

I promise

You’ll ne'er see mee agaen

I’ll dissappear intothe nite like some great magician

And I’ll nevah come back until that clokk strike thirteen times

<br/>

Magic…

Thass some'in' I haappen to know

I learne' from an ol' man on the syde of the road

Somewhere in the mi'le of the night on hiway ninety fo''

<br/>

Wut…

What was I juss talkin' abou'?

Where was I? O'yah, can’t seem to figure out

Whyyy I’ve spent soo much time tryin’ to fin' the eeeasy route

<br/>

I

guess I justcan’t get enough

IguessI

Just can’t geeet enough

<br/>

I

Cain’t get enuf

Iguess I jus' cain’t get enough

<br/>

I

Can’t get enough

I jusscan’t get enough

<br/>

I

Just can’t get enough

Just can’t get enough

Just can’t get enough

Just can’t get enough

Just can’t get enough

Just can’t get enough

<br/>
