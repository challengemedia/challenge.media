---
layout: post
tag: [ Poems ]
title: Onward, Man! Onward!
---

<br/>

Sing a song from time before

A song from once upon

Sing of the days that made you sing

A song for all æon

Sing of love and peace and birth


Sing of blood and war

Sing of Was

--- Oh! What there was!

Of all that were, now yore

<br/>

But ne'er forget now tumbles on

The river refuse' to sleep

And to spite winter's insistent drum

The Farmer, He must reap

Let not your feet rest long aside

Your path laid out before

Let not your hands rest idle by

Your pen on the page's shore

<br/>

Onward, man! Onward!

Forever will not wait for you

Onward, man! Onward!

All that's old was new

Onward, man! Onward!

Out there you'll find the True

Onward, man! Onward!

Out there you will find You

<br/>

Onward, man! Onward!

<br/>
