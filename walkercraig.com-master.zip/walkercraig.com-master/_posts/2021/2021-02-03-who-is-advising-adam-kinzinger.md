---
layout: post
tag: [ Read ]
title: Who is Advising Adam Kinzinger?
---

Craig never minds when a politician takes a stance against another politician, but Craig minds when a politician turns on his voters. He asks Adam Kinzinger of Illinois' 16th District, what was he thinking?

---

Using a mid-day talk show impotence commercial template and with all the drama and emotion of a debut YouTube ad for a tech startup app that connects climate change conscious free-range avocados with like-minded fruits and nuts, Kinzinger delivered a 6-minute soliloquy directed toward his Republican Party outlining his new movement as a home for "principled Americans who are tired of the poisonous extremism that has overtaken our beloved nation's politics."

Ew.

<h3><a href="https://www.chicagojournal.com/opinion-who-is-advising-adam-kinzinger/">Read the rest in the Chicago Journal...</a></h3>

<br/>
