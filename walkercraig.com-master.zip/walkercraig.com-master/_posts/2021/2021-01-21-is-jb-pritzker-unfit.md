---
layout: post
tag: [ Read ]
title: Is J.B. Pritzker Unfit to Lead the State of Illinois?
---

It was time for Craig to review Illinois Governor J.B. Pritzker's performance over the last year, most notably his handling of COVID-19 lockdown policies.

---

He long expressed an interest in Politics but it wasn't until J.B. Pritzker found it necessary to fully satisfy the donation requirements of Mike Madigan that he was elected Governor of Illinois. It was his first elected position in public office, and it should be his last.

<h3><a href="https://www.chicagojournal.com/opinion-is-jb-pritzker-unfit/">Read the rest in the Chicago Journal...</a></h3>

<br/>
