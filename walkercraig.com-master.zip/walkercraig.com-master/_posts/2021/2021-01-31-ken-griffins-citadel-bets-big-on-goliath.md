---
layout: post
tag: [ Read ]
title: Ken Griffin's Citadel Bets Big on Goliath as David Grabs his Sling
---

A wild story in the business world broke out last week and Craig couldn't sit on the sidelines.

---

Ken Griffin is about to learn a hard lesson. You are the company you keep.

<h3><a href="https://www.chicagojournal.com/opinion-ken-griffin-citadel-bets-big-on-goliath-as-david-grabs-his-sling/">Read the rest in the Chicago Journal...</a></h3>

<br/>
